//
//  YYImageProfileExample.h
//  YYKitExample
//
//  Created by ibireme on 15/8/10.
//  Copyright (c) 2015 ibireme. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYImageBenchmark : UITableViewController

@end
