//
//  Mier_CommunityViewController.h
//  MierMilitaryNews
//
//  Created by 李响 on 2016/10/24.
//  Copyright © 2016年 miercn. All rights reserved.
//

#import "BaseViewController.h"

@interface Mier_CommunityViewController : BaseViewController

@end
