//
//  CommunityCircleDetailsViewController.h
//  MierMilitaryNews
//
//  Created by 李响 on 2016/10/25.
//  Copyright © 2016年 miercn. All rights reserved.
//

#import "BaseViewController.h"

#import "CommunityCircleModel.h"

@interface CommunityCircleDetailsViewController : BaseViewController

@property (nonatomic , copy ) NSString *circleId;

@end
