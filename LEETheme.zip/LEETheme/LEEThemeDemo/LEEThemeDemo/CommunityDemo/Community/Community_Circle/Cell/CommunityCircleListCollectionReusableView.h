//
//  CommunityCircleListCollectionReusableView.h
//  MierMilitaryNews
//
//  Created by 李响 on 2016/10/26.
//  Copyright © 2016年 miercn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommunityCircleListCollectionReusableView : UICollectionReusableView

/**
 设置标题

 @param title 标题
 */
- (void)configTitle:(NSString *)title;

@end
