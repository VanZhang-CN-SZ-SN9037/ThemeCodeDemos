//
//  CommunityCircleListCell.h
//  MierMilitaryNews
//
//  Created by 李响 on 2016/10/26.
//  Copyright © 2016年 miercn. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CommunityCircleModel.h"

@interface CommunityCircleListCell : UICollectionViewCell

@property (nonatomic , strong ) CommunityCircleModel *model;

@end
