//
//  NightTheme.m
//  MierMilitaryNews
//
//  Created by liuxin on 15/3/12.
//  Copyright (c) 2015年 liuxin. All rights reserved.
//

#import "ThemeManager.h"

@implementation ThemeManager

//[LEETheme startTheme:DAY];
//[LEETheme startTheme:NIGHT];

@end
