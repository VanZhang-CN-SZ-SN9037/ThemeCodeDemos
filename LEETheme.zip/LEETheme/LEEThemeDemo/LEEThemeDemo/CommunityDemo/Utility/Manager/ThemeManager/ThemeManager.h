//
//  NightTheme.h
//  MierMilitaryNews
//
//  Created by liuxin on 15/3/12.
//  Copyright (c) 2015年 liuxin. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <UIKit/UIKit.h>

#import "ThemeConstant.h"

@interface ThemeManager : NSObject


@end
