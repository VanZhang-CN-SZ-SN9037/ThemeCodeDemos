//
//  RankManager.h
//  LEEThemeDemo
//
//  Created by 李响 on 2017/3/16.
//  Copyright © 2017年 lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RankManager : NSObject

+ (NSArray *)rankImageArray;

+ (NSArray *)rankNameArray;

+ (NSArray *)rankIntegralArray;

@end
