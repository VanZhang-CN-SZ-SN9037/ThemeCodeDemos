//
//  MJRefreshGifHeader+UniversalRefresh.h
//  MierMilitaryNews
//
//  Created by 李响 on 16/9/21.
//  Copyright © 2016年 miercn. All rights reserved.
//

#import "MJRefresh.h"

@interface MJRefreshGifHeader (UniversalRefresh)

@end

@interface MJRefreshBackNormalFooter (UniversalRefresh)

@end

@interface MJRefreshAutoNormalFooter (UniversalRefresh)

@end
