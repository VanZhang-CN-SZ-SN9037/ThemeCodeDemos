//
//  main.m
//  ThemeManager
//
//  Created by snail-z on 08/31/2017.
//  Copyright (c) 2017 snail-z. All rights reserved.
//

@import UIKit;
#import "zhAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([zhAppDelegate class]));
    }
}
