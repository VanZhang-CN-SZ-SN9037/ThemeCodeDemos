//
//  zhAppDelegate.h
//  ThemeManager
//
//  Created by snail-z on 08/31/2017.
//  Copyright (c) 2017 snail-z. All rights reserved.
//

@import UIKit;

@interface zhAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
